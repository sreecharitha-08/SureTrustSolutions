import numpy as np
import os
from email.message import EmailMessage
import smtplib

TOTAL_SCORE = 100
problem_weights = {
    "problem1": 20,
    "problem2": 20,
    "problem3": 20,
    "problem4": 20,
    "problem5": 20,
}

def test_problem1(func):
    score = 0
    max_score = problem_weights["problem1"]
    try:
        arr_doubled, total, reshaped = func()
        if arr_doubled.shape == (21,):
            score += max_score // 3
        if total == sum([x * 2 for x in range(10, 51, 2)]):
            score += max_score // 3
        if reshaped.shape == (5, 4):
            score += max_score - 2 * (max_score // 3)
        print(f"[✔] Problem 1 Passed — Score: {score}/{max_score}")
    except Exception as e:
        print(f"[✘] Problem 1 Failed — Score: {score}/{max_score} — Error: {e}")
    return score

# def test_problem1(func, f):
#     score = 0
#     max_score = problem_weights["problem1"]
#     try:
#         arr_doubled, total, reshaped = func()
#         if arr_doubled.shape == (21,):
#             score += max_score // 3
#         if total == sum([x * 2 for x in range(10, 51, 2)]):
#             score += max_score // 3
#         if reshaped.shape == (5, 4):
#             score += max_score - 2 * (max_score // 3)
#         result = f"[✔] Problem 1 Passed — Score: {score}/{max_score}"
#     except Exception as e:
#         result = f"[✘] Problem 1 Failed — Score: {score}/{max_score} — Error: {e}"
#     f.write(result + "\n")
#     print(result)
#     return score

def test_problem2(func):
    score = 0
    max_score = problem_weights["problem2"]
    try:
        rows, col, subarray = func()
        if rows.shape == (2, 5):
            score += max_score // 3
        if col.shape == (5,):
            score += max_score // 3
        if subarray.shape == (3, 3):
            score += max_score - 2 * (max_score // 3)
        print(f"[✔] Problem 2 Passed — Score: {score}/{max_score}")
    except Exception as e:
        print(f"[✘] Problem 2 Failed — Score: {score}/{max_score} — Error: {e}")
    return score

# def test_problem2(func, f):
#     score = 0
#     max_score = problem_weights["problem2"]
#     try:
#         rows, col, subarray = func()
#         if rows.shape == (2, 5):
#             score += max_score // 3
#         if col.shape == (5,):
#             score += max_score // 3
#         if subarray.shape == (3, 3):
#             score += max_score - 2 * (max_score // 3)
#         result = f"[✔] Problem 2 Passed — Score: {score}/{max_score}"
#     except Exception as e:
#         result = f"[✘] Problem 2 Failed — Score: {score}/{max_score} — Error: {e}"
#     f.write(result + "\n")
#     print(result)
#     return score

def test_problem3(func):
    score = 0
    max_score = problem_weights["problem3"]
    try:
        divisible_by_3, replaced_array = func()
        if all(divisible_by_3 % 3 == 0):
            score += max_score // 2
        if (replaced_array > 15).sum() == 0:
            score += max_score - (max_score // 2)
        print(f"[✔] Problem 3 Passed — Score: {score}/{max_score}")
    except Exception as e:
        print(f"[✘] Problem 3 Failed — Score: {score}/{max_score} — Error: {e}")
    return score

# def test_problem3(func, f):
#     score = 0
#     max_score = problem_weights["problem3"]
#     try:
#         divisible_by_3, replaced_array = func()
#         if all(divisible_by_3 % 3 == 0):
#             score += max_score // 2
#         if (replaced_array > 15).sum() == 0:
#             score += max_score - (max_score // 2)
#         result = f"[✔] Problem 3 Passed — Score: {score}/{max_score}"
#     except Exception as e:
#         result = f"[✘] Problem 3 Failed — Score: {score}/{max_score} — Error: {e}"
#     f.write(result + "\n")
#     print(result)
#     return score

def test_problem4(func):
    score = 0
    max_score = problem_weights["problem4"]
    try:
        row_means, col_sums = func()
        if len(row_means) == 4:
            score += max_score // 2
        if len(col_sums) == 4:
            score += max_score - (max_score // 2)
        print(f"[✔] Problem 4 Passed — Score: {score}/{max_score}")
    except Exception as e:
        print(f"[✘] Problem 4 Failed — Score: {score}/{max_score} — Error: {e}")
    return score

# def test_problem4(func, f):
#     score = 0
#     max_score = problem_weights["problem4"]
#     try:
#         row_means, col_sums = func()
#         if len(row_means) == 4:
#             score += max_score // 2
#         if len(col_sums) == 4:
#             score += max_score - (max_score // 2)
#         result = f"[✔] Problem 4 Passed — Score: {score}/{max_score}"
#     except Exception as e:
#         result = f"[✘] Problem 4 Failed — Score: {score}/{max_score} — Error: {e}"
#     f.write(result + "\n")
#     print(result)
#     return score

def test_problem5(func):
    score = 0
    max_score = problem_weights["problem5"]
    try:
        vstacked, hstacked, split_arrays = func()
        if vstacked.shape == (2, 3):
            score += max_score // 3
        if hstacked.shape == (6,):
            score += max_score // 3
        if len(split_arrays) == 2:
            score += max_score - 2 * (max_score // 3)
        print(f"[✔] Problem 5 Passed — Score: {score}/{max_score}")
    except Exception as e:
        print(f"[✘] Problem 5 Failed — Score: {score}/{max_score} — Error: {e}")
    return score

# def test_problem5(func, f):
#     score = 0
#     max_score = problem_weights["problem5"]
#     try:
#         vstacked, hstacked, split_arrays = func()
#         if vstacked.shape == (2, 3):
#             score += max_score // 3
#         if hstacked.shape == (6,):
#             score += max_score // 3
#         if len(split_arrays) == 2:
#             score += max_score - 2 * (max_score // 3)
#         result = f"[✔] Problem 5 Passed — Score: {score}/{max_score}"
#     except Exception as e:
#         result = f"[✘] Problem 5 Failed — Score: {score}/{max_score} — Error: {e}"
#     f.write(result + "\n")
#     print(result)
#     return score


def run_all_tests(student_functions, student_name):
    total = 0
    print("=== NumPy Assignment Evaluation ===")
    total += test_problem1(student_functions['problem1'])
    total += test_problem2(student_functions['problem2'])
    total += test_problem3(student_functions['problem3'])
    total += test_problem4(student_functions['problem4'])
    total += test_problem5(student_functions['problem5'])
    print(f"\n🏁 Final Score: {total}/{TOTAL_SCORE}")

    safe_name = student_name.strip().replace(" ", "_")
    filename = f"final_score_{safe_name}.txt"
    
    with open(filename, "w") as f:
        f.write(f"18th April 2025 NumPy Class Test Score Report\n")
        f.write(f"Student: {student_name}\n\n")
        final_line = f"\n Final Score: {total}/{TOTAL_SCORE}"
        f.write(final_line + "\n")

# def run_all_tests(student_functions, student_name):
#     total = 0
#     safe_name = student_name.strip().replace(" ", "_")
#     filename = f"final_score_{safe_name}.txt"
    
#     with open(filename, "w") as f:
#         f.write(f"NumPy Assignment Score Report\n")
#         f.write(f"Student: {student_name}\n\n")

#         def write_and_return(text):
#             f.write(text + "\n")
#             print(text)
#             return text

#         write_and_return("=== NumPy Assignment Evaluation ===")
#         total += test_problem1(student_functions['problem1'], f)
#         total += test_problem2(student_functions['problem2'], f)
#         total += test_problem3(student_functions['problem3'], f)
#         total += test_problem4(student_functions['problem4'], f)
#         total += test_problem5(student_functions['problem5'], f)

#         final_line = f"\n🏁 Final Score: {total}/{TOTAL_SCORE}"
#         f.write(final_line + "\n")
#         print(final_line)


# # === CONFIGURATION (Edit before use) ===
# APP_PASSWORD = "suretrust123"            # Replace with Gmail App Password
# RECEIVER_EMAIL = "tarunbjoseph@example.com" # Replace with your personal email

# def email_score_file(student_name, student_email):
#     safe_name = student_name.strip().replace(" ", "_")
#     filename = f"final_score_{safe_name}.txt"

#     if not os.path.exists(filename):
#         print("❌ Score file not found. Please ensure tests were run successfully.")
#         return

#     msg = EmailMessage()
#     msg['Subject'] = f"NumPy Assignment Score: {student_name}"
#     msg['From'] = student_email
#     msg['To'] = RECEIVER_EMAIL
#     msg.set_content(f"Hi,\n\nPlease find attached the score report for {student_name}.\n\nRegards,\nAuto Grader")

#     with open(filename, 'rb') as f:
#         msg.add_attachment(f.read(), maintype='text', subtype='plain', filename=filename)

#     try:
#         with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
#             smtp.login(student_email, APP_PASSWORD)
#             smtp.send_message(msg)
#         print(f"📧 Email sent successfully to {RECEIVER_EMAIL}")
#     except Exception as e:
#         print(f"❌ Failed to send email: {e}")